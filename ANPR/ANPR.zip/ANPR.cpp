#include "stdafx.h"
// #include "ANPR.h"


#pragma once
#include "opencv/cv.h"
#include "opencv/highgui.h"
#include "opencv2/opencv.hpp"
#include "opencv2/core/core.hpp"

namespace CppCLR_WinformsProjekt {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Drawing::Imaging;
	using namespace System::Data::SqlClient;
	using namespace System::Runtime::InteropServices;
	using namespace System::IO;
	using namespace std;
	using namespace cv;		// Required namespace for OpenCV


	VideoCapture capture;
	Mat frame;

	/// <summary>
	/// Zusammenfassung f�r Form1
	/// </summary>
	public ref class ANPR : public System::Windows::Forms::Form
	{
	
	private:
		System::String^ connString;
		SqlConnection^ connection;
		SqlCommand^ cmd;
		SqlDataAdapter^ adapter;
		DataSet^ dataSet;

	public:
		
		ANPR(void)
		{
			InitializeComponent();
			//
			//TODO: Konstruktorcode hier hinzuf�gen.
			//

			
			// Initialization and instantiation
			connString = "Data Source = DESKTOP-S4CCM9R\\SQLEXPRESS; Initial Catalog = ANPR; Integrated Security=true";
			connection = gcnew SqlConnection(connString);
		}

	protected:
		/// <summary>
		/// Verwendete Ressourcen bereinigen.
		/// </summary>
		~ANPR()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TabControl^  mainTabControl;
	private: System::Windows::Forms::TabPage^  addLicensePlateTabPage;
	private: System::Windows::Forms::TabPage^  parkingINTabPage;

	protected:


	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  LicencePlateNumbertxt;
	private: System::Windows::Forms::Button^  addLicencePlatebtn;
	private: System::Windows::Forms::PictureBox^  pictureBox;
	private: System::Windows::Forms::Button^  Clickbtn;
	private: System::Windows::Forms::TrackBar^  trackBar;
	private: System::Windows::Forms::Timer^  timer;
	private: System::Windows::Forms::TabPage^  parkingTabPage;
	private: System::Windows::Forms::DataGridView^  dataGridView;

	private: System::ComponentModel::IContainer^  components;



	private:
		
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung.
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->mainTabControl = (gcnew System::Windows::Forms::TabControl());
			this->addLicensePlateTabPage = (gcnew System::Windows::Forms::TabPage());
			this->addLicencePlatebtn = (gcnew System::Windows::Forms::Button());
			this->LicencePlateNumbertxt = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->parkingINTabPage = (gcnew System::Windows::Forms::TabPage());
			this->trackBar = (gcnew System::Windows::Forms::TrackBar());
			this->Clickbtn = (gcnew System::Windows::Forms::Button());
			this->pictureBox = (gcnew System::Windows::Forms::PictureBox());
			this->parkingTabPage = (gcnew System::Windows::Forms::TabPage());
			this->dataGridView = (gcnew System::Windows::Forms::DataGridView());
			this->timer = (gcnew System::Windows::Forms::Timer(this->components));
			this->mainTabControl->SuspendLayout();
			this->addLicensePlateTabPage->SuspendLayout();
			this->parkingINTabPage->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox))->BeginInit();
			this->parkingTabPage->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView))->BeginInit();
			this->SuspendLayout();
			// 
			// mainTabControl
			// 
			this->mainTabControl->Controls->Add(this->addLicensePlateTabPage);
			this->mainTabControl->Controls->Add(this->parkingINTabPage);
			this->mainTabControl->Controls->Add(this->parkingTabPage);
			this->mainTabControl->Location = System::Drawing::Point(13, 13);
			this->mainTabControl->Name = L"mainTabControl";
			this->mainTabControl->SelectedIndex = 0;
			this->mainTabControl->Size = System::Drawing::Size(527, 346);
			this->mainTabControl->TabIndex = 0;
			// 
			// addLicensePlateTabPage
			// 
			this->addLicensePlateTabPage->Controls->Add(this->addLicencePlatebtn);
			this->addLicensePlateTabPage->Controls->Add(this->LicencePlateNumbertxt);
			this->addLicensePlateTabPage->Controls->Add(this->label1);
			this->addLicensePlateTabPage->Location = System::Drawing::Point(4, 22);
			this->addLicensePlateTabPage->Name = L"addLicensePlateTabPage";
			this->addLicensePlateTabPage->Padding = System::Windows::Forms::Padding(3);
			this->addLicensePlateTabPage->Size = System::Drawing::Size(519, 320);
			this->addLicensePlateTabPage->TabIndex = 0;
			this->addLicensePlateTabPage->Text = L"Add License Plate";
			this->addLicensePlateTabPage->UseVisualStyleBackColor = true;
			// 
			// addLicencePlatebtn
			// 
			this->addLicencePlatebtn->Location = System::Drawing::Point(136, 34);
			this->addLicencePlatebtn->Name = L"addLicencePlatebtn";
			this->addLicencePlatebtn->Size = System::Drawing::Size(111, 23);
			this->addLicencePlatebtn->TabIndex = 2;
			this->addLicencePlatebtn->Text = L"Add License Plate";
			this->addLicencePlatebtn->UseVisualStyleBackColor = true;
			this->addLicencePlatebtn->Click += gcnew System::EventHandler(this, &ANPR::addLicencePlatebtn_Click);
			// 
			// LicencePlateNumbertxt
			// 
			this->LicencePlateNumbertxt->Location = System::Drawing::Point(136, 7);
			this->LicencePlateNumbertxt->Name = L"LicencePlateNumbertxt";
			this->LicencePlateNumbertxt->Size = System::Drawing::Size(154, 20);
			this->LicencePlateNumbertxt->TabIndex = 1;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(7, 7);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(112, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Licence Plate Number";
			// 
			// parkingINTabPage
			// 
			this->parkingINTabPage->Controls->Add(this->trackBar);
			this->parkingINTabPage->Controls->Add(this->Clickbtn);
			this->parkingINTabPage->Controls->Add(this->pictureBox);
			this->parkingINTabPage->Location = System::Drawing::Point(4, 22);
			this->parkingINTabPage->Name = L"parkingINTabPage";
			this->parkingINTabPage->Padding = System::Windows::Forms::Padding(3);
			this->parkingINTabPage->Size = System::Drawing::Size(519, 320);
			this->parkingINTabPage->TabIndex = 1;
			this->parkingINTabPage->Text = L"Parking In";
			this->parkingINTabPage->UseVisualStyleBackColor = true;
			// 
			// trackBar
			// 
			this->trackBar->Location = System::Drawing::Point(10, 237);
			this->trackBar->Name = L"trackBar";
			this->trackBar->Size = System::Drawing::Size(104, 45);
			this->trackBar->TabIndex = 2;
			// 
			// Clickbtn
			// 
			this->Clickbtn->Location = System::Drawing::Point(130, 259);
			this->Clickbtn->Name = L"Clickbtn";
			this->Clickbtn->Size = System::Drawing::Size(75, 23);
			this->Clickbtn->TabIndex = 1;
			this->Clickbtn->Text = L"Start";
			this->Clickbtn->UseVisualStyleBackColor = true;
			this->Clickbtn->Click += gcnew System::EventHandler(this, &ANPR::Clickbtn_Click);
			// 
			// pictureBox
			// 
			this->pictureBox->Location = System::Drawing::Point(7, 7);
			this->pictureBox->Name = L"pictureBox";
			this->pictureBox->Size = System::Drawing::Size(341, 224);
			this->pictureBox->TabIndex = 0;
			this->pictureBox->TabStop = false;
			// 
			// parkingTabPage
			// 
			this->parkingTabPage->Controls->Add(this->dataGridView);
			this->parkingTabPage->Location = System::Drawing::Point(4, 22);
			this->parkingTabPage->Name = L"parkingTabPage";
			this->parkingTabPage->Size = System::Drawing::Size(519, 320);
			this->parkingTabPage->TabIndex = 2;
			this->parkingTabPage->Text = L"Parking Records";
			this->parkingTabPage->UseVisualStyleBackColor = true;
			// 
			// dataGridView
			// 
			this->dataGridView->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView->Location = System::Drawing::Point(4, 4);
			this->dataGridView->Name = L"dataGridView";
			this->dataGridView->Size = System::Drawing::Size(512, 313);
			this->dataGridView->TabIndex = 0;
			// 
			// timer
			// 
			this->timer->Interval = 30;
			this->timer->Tick += gcnew System::EventHandler(this, &ANPR::timer_Tick);
			// 
			// ANPR
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(552, 371);
			this->Controls->Add(this->mainTabControl);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"ANPR";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"ANPR";
			this->Load += gcnew System::EventHandler(this, &ANPR::ANPR_Load);
			this->mainTabControl->ResumeLayout(false);
			this->addLicensePlateTabPage->ResumeLayout(false);
			this->addLicensePlateTabPage->PerformLayout();
			this->parkingINTabPage->ResumeLayout(false);
			this->parkingINTabPage->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox))->EndInit();
			this->parkingTabPage->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void ANPR_Load(System::Object^  sender, System::EventArgs^  e) {
		
		DataSet^ dataSet = fillParkingDataGrid();
		dataGridView->DataSource = dataSet->Tables[0];
		dataGridView->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::DisplayedCells;
		dataGridView->AutoSizeRowsMode = System::Windows::Forms::DataGridViewAutoSizeRowsMode::DisplayedCells;
		
	}

	private: System::Void addLicencePlatebtn_Click(System::Object^  sender, System::EventArgs^  e) {
		
		addLicensePlate();

	}

	private: System::Void timer_Tick(System::Object^  sender, System::EventArgs^  e) {
		capture.read(frame);
		frame = finder(frame, "haarcascade_frontalface_alt.xml");

		System::Drawing::Bitmap^ bitmapImg = gcnew System::Drawing::Bitmap
		(frame.cols, frame.rows, frame.step,
			System::Drawing::Imaging::PixelFormat::Format24bppRgb, (System::IntPtr) frame.data);
		
		System::Drawing::Bitmap^ resultImg = gcnew System::Drawing::Bitmap
		(pictureBox->Width, pictureBox->Height);

		System::Drawing::Graphics^ g = System::Drawing::Graphics::FromImage(resultImg);
		g->DrawImage(bitmapImg, 0,0, pictureBox->Width, pictureBox->Height);
		pictureBox->Image = resultImg;

		pictureBox->Refresh();
	}
	

	private: System::Void Clickbtn_Click(System::Object^  sender, System::EventArgs^  e) {
		if (Clickbtn->Text == "Start")
		{
			trackBar->Minimum = 0;
			trackBar->Maximum = 1000;
			Clickbtn->Text = "Stop";

			capture.open(0);

			if (!capture.isOpened())  // check if we succeeded
				MessageBox::Show("Video Capture failed", "Error", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
			else
			{
				timer->Start();
			}
			
		}
		else 
		{
			capture.release();
			timer->Stop();
			
			addParkingIn();

			Clickbtn->Text = "Start";
		}

		
	}


	private: void addLicensePlate()
	{
		System::String^ licensePlateNumber = this->LicencePlateNumbertxt->Text;

		try
		{
			connection->Open();
			cmd = gcnew SqlCommand();
			cmd->Connection = connection;
			cmd->CommandText = "AddLicensePlate";
			cmd->CommandType = CommandType::StoredProcedure;
			cmd->Parameters->Add("@LicensePlateNumber", SqlDbType::NVarChar)->Value = licensePlateNumber;
			cmd->ExecuteNonQuery();
			MessageBox::Show(licensePlateNumber + " sucessfully added.", "Sucessfully Added", MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
		catch (System::Exception^ ex)
		{
			MessageBox::Show(ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
		}
		finally
		{
			connection->Close();
		}
	}
	private: System::Data::DataSet^ fillParkingDataGrid()
	{
		cmd = gcnew SqlCommand();
		adapter = gcnew SqlDataAdapter();
		dataSet = gcnew DataSet();

		try
		{
			cmd->Connection = connection;
			cmd->CommandText = "GetAllParkingRecords";
			cmd->CommandType = CommandType::StoredProcedure;

			adapter->SelectCommand = cmd;
			adapter->Fill(dataSet);
			return dataSet;
		}
		catch (System::Exception^ ex)
		{
			MessageBox::Show(ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
		}
		finally
		{
			connection->Close();
		}

		return dataSet;
	}
	private: void addParkingIn()
	{
		try
		{
			connection->Open();
			cmd = gcnew SqlCommand();
			cmd->Connection = connection;
			cmd->CommandText = "AddParkingIn";
			cmd->CommandType = CommandType::StoredProcedure;
			cmd->Parameters->Add("@LicensePlateID", SqlDbType::Int)->Value = 2;

			Image^ theImage = pictureBox->Image;
			MemoryStream^ memoryStream = gcnew MemoryStream();

			theImage->Save(memoryStream, System::Drawing::Imaging::ImageFormat::Jpeg);

			cmd->Parameters->Add("@ParkingInImage", SqlDbType::VarBinary)->Value = memoryStream->ToArray();
			memoryStream->Close();
			cmd->ExecuteNonQuery();
			MessageBox::Show("Parked IN sucessfully.", "Parked IN", MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
		catch (System::Exception^ ex)
		{
			MessageBox::Show(ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
		}
		finally
		{
			connection->Close();
		}
	}
	private: Mat finder(Mat img, string cass)
	{

		resize(img, img, cv::Size(300, 200));
		// Load cascate classifier placed in sulution folder
		CascadeClassifier detector;
		string cascadeName = cass;
		bool loaded = detector.load(cascadeName);
		// Parameters of detectMultiscale Cascade Classifier
		int groundThreshold = 2;
		double scaleStep = 1.1;
		cv::Size minimalObjectSize(45, 45);
		cv::Size maximalObjectSize(130, 130);
		// Vector of returned found
		vector<Rect> found;
		// Convert input to greyscale 
		Mat image_grey;
		cvtColor(img, image_grey, CV_BGR2GRAY);
		// why not
		found.clear();
		// Detect found
		detector.detectMultiScale(image_grey, found, scaleStep, groundThreshold, 0 | 2, minimalObjectSize, maximalObjectSize);
		// Draw circles on the detected found
		for (int i = 0; i < found.size(); i++)
		{
			cv::Point pt1(found[i].x, found[i].y); // Display detected faces on main window - live stream from camera
			cv::Point pt2((found[i].x + found[i].height), (found[i].y + found[i].width));
			rectangle(img, pt1, pt2, Scalar(0, 255, 0), 2, 8, 0);

		}

		return img;

	}

};
}
